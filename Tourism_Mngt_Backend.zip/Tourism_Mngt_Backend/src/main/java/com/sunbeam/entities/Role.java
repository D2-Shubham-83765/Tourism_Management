package com.sunbeam.entities;

public enum Role {
	USER, ADMIN
}
