package com.sunbeam.service;

import com.sunbeam.dto.AdminDTO;

public interface AdminService {
	String addNewAdmin(AdminDTO dto);
}
